package com.lsjt.ambition.frame;

import com.lsjt.ambition.part.*;
import com.lsjt.ambition.utility.GameUtility;
import com.sun.org.apache.bcel.internal.generic.GETFIELD;
import org.ietf.jgss.GSSManager;

import javax.swing.*;
import javax.swing.event.MenuListener;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class MainFrame extends JFrame {

    /*
     * 游戏状态 0未开始 1游戏中 2暂停 3通关成功 4通关失败
     *
     *  游戏默认状态 置为0，即游戏未开始
     *
     */
    public static int GameState = 0;//游戏的状态
    private int width = 1500;//界面的宽
    private int height = 1000;//界面的高

    private Image offscreenImage;//解决屏闪使用的缓存Image对象
    private Background background = new Background();//游戏背景类
    private Enemy enemyFish;

    private Double random;
    private int timeCounter = 0;//记录绘图的次数

    private OwnFish ownFish = new OwnFish();//    我方鱼

    public void launch() {
        this.setTitle("大鱼吃小鱼");//设置窗口标题
        this.setSize(width, height);//设置窗口大小
        this.setResizable(false);//设置窗口大小不可改变
        this.setLocationRelativeTo(null);//设置窗口在屏幕居中位置
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置窗口关闭按钮的关闭方式
        this.setVisible(true);//设置窗口是否可见

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
                if (mouseEvent.getButton() == 1 && GameState == 0) {
                    GameState = 1;
                    repaint();
                }else if(mouseEvent.getButton()==1 && (GameState==2 || GameState==4))
                {
                    GameState=1;
                    restart();
                }
            }
        });

        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    GameUtility.MOVE_UP = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    GameUtility.MOVE_DOWN = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    GameUtility.MOVE_RIGHT = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    GameUtility.MOVE_LEFT = true;
                }
                if(e.getKeyCode()==KeyEvent.VK_SPACE)
                {
                    switch (GameState)
                    {
                        case 2:
                            GameState=1;
                            break;
                        case 1://若游戏进行中，将游戏暂停
                            GameState=2;
                            GameUtility.drawString(getGraphics(),"游戏暂停",Color.GREEN,60,620,470);
                            break;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    GameUtility.MOVE_UP = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    GameUtility.MOVE_DOWN = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    GameUtility.MOVE_RIGHT = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    GameUtility.MOVE_LEFT = false;
                }
            }
        });

        while (true)//出现文字闪动，使用双缓存解决屏闪问题
        {
            repaint();
            timeCounter++;
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void paint(Graphics g) {

        offscreenImage = createImage(width, height);
        Graphics graphics = offscreenImage.getGraphics();
//        graphics.drawImage(GameUtility.backgroundImage,0,0,null);
        background.paintSelfhood(graphics, ownFish.getLevel());

        switch (GameState) {
            case 0://0未开始
//                graphics.drawImage(GameUtility.backgroundImage,0,0,null);
                //为启动界面添加文字---------------------------------------------
//                graphics.setColor(Color.green);//设置画笔颜色
//                graphics.setFont(new Font("宋体",Font.BOLD,60));//设置字体
//                graphics.drawString("开始",720,470);
                //为启动界面添加文字---------------------------------------------
                break;
            case 1://1游戏中
//                background.paintSelfhood(graphics);
//                leftEnemy.paintSelfhood(graphics);
//                leftEnemy.setX(leftEnemy.getX()+ leftEnemy.getSpeed());
                generateEnemyFish(graphics);
                ownFish.paintSelf(graphics);

//                graphics.setColor(Color.RED);
//                graphics.setFont(new Font("宋体",Font.BOLD,80));//设置字体
//                graphics.drawString("分数:\t"+GameUtility.scoreOfOwnFish,200,200);

                break;
            case 2://2暂停
                return;
            case 3://  3通关成功
                ownFish.paintSelf(graphics);
//                graphics.setColor(Color.ORANGE);
//                graphics.setFont(new Font("宋体",Font.BOLD,80));
//                graphics.drawString("分数"+GameUtility.scoreOfOwnFish,200,200);
//                graphics.drawString("胜利",(width-80)/2,(height-80)/2);
                break;
            case 4://4通关失败
                for (Enemy enemy : GameUtility.enemyList) {
                    enemy.paintSelfhood(graphics);
                }
                break;
            default:
                break;

        }
        g.drawImage(offscreenImage, 0, 0, width, height, null);
    }

    public void generateEnemyFish(Graphics graphics)//绘制多条敌方鱼
    {
        //设置关卡难度
        if (GameUtility.scoreOfOwnFish < 5) {
            GameUtility.GameStage = 0;
            ownFish.setLevel(1);
        } else if (GameUtility.scoreOfOwnFish <= 20) {
            GameUtility.GameStage = 1;
            ownFish.setLevel(1);
        } else if (GameUtility.scoreOfOwnFish <= 60) {
            GameUtility.GameStage = 2;
            ownFish.setLevel(2);
        } else if (GameUtility.scoreOfOwnFish <= 120) {
            GameUtility.GameStage = 3;
            ownFish.setLevel(3);
        } else if (GameUtility.scoreOfOwnFish <= 150) {
            GameUtility.GameStage = 4;
            ownFish.setLevel(3);
        } else if (GameUtility.scoreOfOwnFish > 300)//游戏胜利
        {
            GameState = 3;//游戏状态置为3
        }

        random = Math.random();
        switch (GameUtility.GameStage)//在对应的关卡，生成不同的敌方鱼
        {
            case 0:
                //每隔多少毫秒生成一条鱼
                if (timeCounter % 5 == 0) {
//                    random = Math.random();
                    if (random > 0.5) {
                        enemyFish = new LeftEnemy1();
                    } else {
                        enemyFish = new RightEnemy1();
                    }
                    GameUtility.enemyList.add(enemyFish);
                }
                break;

            case 1:
                if (timeCounter % 20 == 0) {
//                    random = Math.random();
                    if (random > 0.5) {
                        enemyFish = new LeftEnemy2();
                    } else {
                        enemyFish = new RightEnemy2();
                    }
                    GameUtility.enemyList.add(enemyFish);

                }

                break;
            case 2:
                if (timeCounter % 30 == 0) {
//                    random = Math.random();
                    if (random > 0.5) {
                        enemyFish = new LeftEnemy3();
                    } else {
                        enemyFish = new RightEnemy3();
                    }
                    GameUtility.enemyList.add(enemyFish);
                }
                break;
            case 3:
                if (timeCounter % 50 == 0) {
//                    random = Math.random();
                    if (random > 0.5) {
                        enemyFish = new LeftEnemy4();
                    } else {
                        enemyFish = new RightEnemy4();
                    }
                    GameUtility.enemyList.add(enemyFish);
                }
                break;

        }



        for (Enemy enemy : GameUtility.enemyList) {
//            System.out.println("GameUtility.enemyList = " + GameUtility.enemyList);
            enemy.setX(enemy.getX() + enemy.getDirection() * enemy.getSpeed());
            enemy.paintSelfhood(graphics);
            //检测敌方鱼与我方鱼的碰撞
            if (enemy.getRectangle().intersects(ownFish.getRectangle())) {
                if(ownFish.getLevel()>=enemy.getType())//如果我方鱼的级别比敌方鱼的大，则我方鱼吃掉敌方鱼
                {
                    System.out.println("ownFish.getLevel() = " + ownFish.getLevel());
                    System.out.println("enemy.getType() = " + enemy.getType());
                    enemy.setX(-500);
                    enemy.setY(-500);
                }else//否则我方鱼的级别比敌方鱼的小，则游戏失败
                {
                    GameState=4;//游戏状态置为4，即游戏失败
                }

                //碰撞到敌方鱼后，我方鱼的分值自增
                GameUtility.scoreOfOwnFish+=enemyFish.getScore();
            }else if(enemy.getX()<-50 || enemy.getX()>2000)//将没有碰撞到的、游走的鱼显重新显示出来
            {
                enemy.setY((int)(Math.random()*(height-100)+100));
                enemy.setX(enemy.getX()>2000?-50:2000);
            }

        }
    }

    public void restart()
    {
        GameState=1;//游戏状态置为1，游戏进行中
        GameUtility.enemyList.clear();//清空所有敌方鱼
        timeCounter=0;
        ownFish.setLevel(1);//我方鱼的级别
        GameUtility.scoreOfOwnFish=0;//我方鱼的得分
        ownFish.setX(600);
        ownFish.setY(300);
        ownFish.setWidth(77);
        ownFish.setHeight(53);
    }


    public static void main(String[] args) {
        MainFrame mainFrame = new MainFrame();
        mainFrame.launch();
    }
}
