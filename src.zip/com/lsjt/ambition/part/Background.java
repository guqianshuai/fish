package com.lsjt.ambition.part;

import com.lsjt.ambition.frame.MainFrame;
import com.lsjt.ambition.utility.GameUtility;
import java.awt.*;

//游戏开始时的背景
public class Background {

    public void paintSelfhood(Graphics graphics, int ownFishLevel) {
        graphics.drawImage(GameUtility.backgroundImage, 0, 0, null);

        switch (MainFrame.GameState) {
            case 0://游戏未开始
                GameUtility.drawString(graphics, "开始", Color.GREEN, 60, 720, 470);
                break;
            case 1://游戏中
                GameUtility.drawString(graphics, "分数:\t" + GameUtility.scoreOfOwnFish, Color.RED, 60, 100, 200);
                GameUtility.drawString(graphics, "等级:\t" + ownFishLevel, Color.RED, 60, 500, 200);
                GameUtility.drawString(graphics, "难度:\t" + GameUtility.GameStage, Color.RED, 60, 900, 200);

                break;
            case 2://暂停
                break;
            case 3://通关成功
                GameUtility.drawString(graphics, "分数:\t" + GameUtility.scoreOfOwnFish, Color.RED, 60, 100, 200);
                GameUtility.drawString(graphics, "等级:\t" + ownFishLevel, Color.RED, 60, 500, 200);
                GameUtility.drawString(graphics, "难度:\t" + GameUtility.GameStage, Color.RED, 60, 900, 200);
                GameUtility.drawString(graphics,"胜利",Color.ORANGE,60,670,420);
                break;
            case 4://4通关失败
                GameUtility.drawString(graphics, "分数:\t" + GameUtility.scoreOfOwnFish, Color.RED, 60, 100, 200);
                GameUtility.drawString(graphics, "等级:\t" + ownFishLevel, Color.RED, 60, 500, 200);
                GameUtility.drawString(graphics, "难度:\t" + GameUtility.GameStage, Color.RED, 60, 900, 200);
                GameUtility.drawString(graphics,"失败",Color.ORANGE,60,670,420);
                break;
            default:
                break;
        }


    }
}
