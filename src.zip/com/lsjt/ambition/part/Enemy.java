package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

import java.awt.*;
import java.util.Random;

//敌方父类
public class Enemy {
    //敌方图片
    protected Image image;
    //敌方的宽
    protected int width;
    //敌方的高
    protected int height;
    //敌方所在的坐标x
    protected int x;
    //敌方所在的坐标y
    protected int y;
    //敌方的移动速度
    protected int speed;
    //敌方的移动方向
    protected int direction=1;
    //敌方的类型
    protected int type;
    //分值
    protected int score;

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    //绘制自身的方法
    public void paintSelfhood(Graphics g)
    {
        g.drawImage(image,x,y,width,height,null);
    }

    //获取自身矩形 用于碰撞检测
    public Rectangle getRectangle()
    {
        return new Rectangle(x,y,width,height);
    }
}


