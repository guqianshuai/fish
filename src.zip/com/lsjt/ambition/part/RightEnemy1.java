package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class RightEnemy1 extends LeftEnemy1
{
    public RightEnemy1()
    {
        this.x=2000;
        this.direction=-1;
        this.image= GameUtility.rightEnemyFish1;
    }
}
