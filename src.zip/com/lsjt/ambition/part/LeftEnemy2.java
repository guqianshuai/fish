package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class LeftEnemy2 extends Enemy
{
    public LeftEnemy2() {
        this.x=-50;
        this.y=(int)(Math.random()*(1000-200+1)+200);
        this.width=86;
        this.height=55;
        this.speed=10;
        this.score=2;
        this.type=2;
        this.image= GameUtility.leftEnemyFish2;
    }
}

