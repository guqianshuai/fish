package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class RightEnemy2 extends LeftEnemy2
{
    public RightEnemy2()
    {
        this.x=2000;
        this.direction=-1;
        this.image= GameUtility.rightEnemyFish2;
    }
}
