package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

import java.awt.*;

public class OwnFish {

    //我方鱼的图片
    protected Image image = GameUtility.leftOwnFish;
    //我方所在的坐标x
    protected int x = 600;
    //我方所在的坐标y
    protected int y = 300;
    //我方鱼的宽
    protected int width = 77;
    //我方鱼的高
    protected int height = 53;
    //我的移动速度
    protected int speed = 20;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    //等级
    protected int level=1;

    //绘制自身的方法
    public void paintSelf(Graphics graphics) {
        move();
        //绘制我方鱼，我方鱼的宽高会随着我方鱼所得的分值而变化
        graphics.drawImage(image, x, y, width+GameUtility.scoreOfOwnFish, height+GameUtility.scoreOfOwnFish, null);
    }

    //获取自身矩形的方法，用于碰撞检测
    public Rectangle getRectangle() {

        return new Rectangle(x, y, width+GameUtility.scoreOfOwnFish, height+GameUtility.scoreOfOwnFish);
    }

    private void move() {
        if (GameUtility.MOVE_UP) {
            this.y = this.y - this.speed;
        }
        if (GameUtility.MOVE_DOWN) {
            this.y = this.y + this.speed;
        }
        if (GameUtility.MOVE_LEFT) {
            this.x = this.x - this.speed;
            image=GameUtility.leftOwnFish;
        }
        if (GameUtility.MOVE_RIGHT) {
            this.x = this.x + this.speed;
            image=GameUtility.rightOwnFish;
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
