package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class RightEnemy4 extends LeftEnemy4
{
    public RightEnemy4()
    {
        this.x=2000;
        this.direction=-1;
        this.image= GameUtility.rightEnemyFish4;
    }
}
