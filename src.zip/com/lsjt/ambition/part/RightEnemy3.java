package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class RightEnemy3 extends LeftEnemy3
{
    public RightEnemy3()
    {
        this.x=2000;
        this.direction=-1;
        this.image= GameUtility.rightEnemyFish3;
    }
}
