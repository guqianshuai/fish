package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class LeftEnemy1 extends Enemy
{
    public LeftEnemy1() {
        this.x=-50;
        this.y=(int)(Math.random()*(1000-200+1)+200);
        this.width=47;
        this.height=24;
        this.speed=10;
        this.score=1;
        this.type=1;
        this.image= GameUtility.leftEnemyFish1;
    }
}

