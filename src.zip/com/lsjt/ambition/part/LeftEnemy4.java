package com.lsjt.ambition.part;

import com.lsjt.ambition.utility.GameUtility;

public class LeftEnemy4 extends Enemy
{
    public LeftEnemy4() {
        this.x=-50;
        this.y=(int)(Math.random()*(1000-200+1)+200);
        this.width=197;
        this.height=110;
        this.speed=20;
        this.score=4;
        this.type=4;
        this.image= GameUtility.leftEnemyFish4;
    }
}

