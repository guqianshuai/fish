package com.lsjt.ambition.utility;

import com.lsjt.ambition.part.Enemy;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GameUtility {

//主界面背景图
    public static Image backgroundImage=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/background.jpg"));

    //敌方鱼(左、右)图

    public static Image leftEnemyFish1=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish1Right.png"));
    public static Image rightEnemyFish1=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish1Left.png"));

    public static Image leftEnemyFish2=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish2Right.png"));
    public static Image rightEnemyFish2=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish2Left.png"));


    public static Image leftEnemyFish3=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish3Right.png"));
    public static Image rightEnemyFish3=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish3Left.png"));


    public static Image leftEnemyFish4=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish4Right.png"));
    public static Image rightEnemyFish4=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/fish4Left.png"));





    //我方鱼
    public static Image leftOwnFish=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/me0.png"));
    public static Image rightOwnFish=Toolkit.getDefaultToolkit().createImage(GameUtility.class.getResource("/image/me1.png"));
    //敌方鱼集合
    public static List<Enemy> enemyList= new ArrayList<>();

//  我方鱼移动方向
    public static boolean MOVE_UP=false;
    public static boolean MOVE_DOWN=false;
    public static boolean MOVE_LEFT=false;
    public static boolean MOVE_RIGHT=false;

    //我方鱼所得积分
    public static int scoreOfOwnFish=0;

    //游戏的困难等级 分别为1、2、3、4
    public static int GameStage=0;

    //绘制文字的工具方法
    public static void drawString(Graphics g,String sourceString,Color color,int size,int x,int y)
    {
        g.setColor(color);
        g.setFont(new Font("宋体",Font.BOLD,size));
        g.drawString(sourceString,x,y);
    }

}
